﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Demo1Application
{
    public partial class _Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {
                string connetionString;
                SqlConnection conn;

                connetionString = @"Password=123456;Persist Security Info=True;User ID=testuser;Initial Catalog=Demodb;Data Source=INAIRDT541647\SQLSERVER2016";

                conn = new SqlConnection(connetionString);

                conn.Open();

                Response.Write("Connection Made Successfully");
                conn.Close();
            }
            catch (Exception EX)
            {

            }
           
        }
    }
}